import React from 'react'
import './Footer.css'

export default function Footer() {
  return (
    <div className='Footer-wrapper'>
      <div className='Footer-text'>
      <p> @Copyright LeaveApply. All Rights Reserved Designed by Amisha</p>
      </div>
    </div>
  )
}
