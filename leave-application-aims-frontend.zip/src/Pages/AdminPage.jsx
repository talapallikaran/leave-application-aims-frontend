import React from "react";
import UserList from "../Components/Admin/UserList/UserList";

export default function AdminPage() {
  return (
    <div>
      <UserList />
    </div>
  );
}
